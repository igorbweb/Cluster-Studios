<?php

/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage None Plate
 * @since None Plate 1.0
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">

<head>
    <!-- Head Tags -->
    <!-- Meta Data -->
    <meta charset="<?php bloginfo('charset'); ?>">

    <!-- Viewport  -->
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>

    <!-- Favicon -->
    <!-- INSERIR AQUI CONFORME CHECKLIST -->

    <meta name="theme-color" content="#ffffff">

    <!-- Meta -->
    <meta name="description" content="<?php echo get_bloginfo('description'); ?>">

    <!-- Wordpress Shit -->
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <?php if (is_singular() && pings_open(get_queried_object())) : ?>
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
    <?php endif; ?>
    <?php wp_head(); ?>

    <!-- jQuery -->
    <script type='text/javascript' src='<?php echo get_template_directory_uri(); ?>/assets/libs/jquery/jquery-1.11.1.min.js'></script>

    <!-- Bootstrap -->
    <link rel='stylesheet' type='text/css' href='<?php echo get_template_directory_uri(); ?>/assets/libs/bootstrap/bootstrap.min.css'>

    <!-- Fancybox -->
    <link rel='stylesheet' type='text/css' href='<?php echo get_template_directory_uri(); ?>/assets/libs/fancybox/fancybox.css'>

    <!-- Swiper -->
    <link rel='stylesheet' type='text/css' href='<?php echo get_template_directory_uri(); ?>/assets/libs/swiper/swiper-bundle.min.css'>

    <!-- Main CSS -->
    <link rel='stylesheet' href='<?php echo get_template_directory_uri(); ?>/assets/css/style.css'>

</head>

<body <?php body_class(); ?>>

    <div class="loading">
        <p><i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw margin-bottom"></i></p>
    </div>
    <!-- RESPONSIVE MENU -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <img src="<?= get_template_directory_uri() ?>/assets/img/Menu.svg" alt="">
                </button>
                <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                    <div class="menu-items d-flex flex-column flex-lg-row align-items-center justify-content-center gap-3 gap-lg-0">
                        <a class="<?= is_front_page() ? 'active' : '' ?>" href="<?= home_url(); ?>">Home</a>
                        <a class="<?= is_page('sobre') ? 'active' : '' ?>" href="<?= home_url('/sobre'); ?>">About Us</a>
                        <a class="<?= is_page('empreendimentos') ? 'active' : '' ?>" href="<?= home_url('/empreendimentos'); ?>">Games</a>
                        <a class="<?= is_page('blog') ? 'active' : '' ?>" href="<?= home_url('/blog'); ?>">Services</a>
                        <a class="<?= is_page('contato') ? 'active' : '' ?>" href="<?= home_url('/contato'); ?>">Contact</a>
                    </div>
                </div>
            </div>
        </nav>
        <hr>
        <div class="container">
            <a href="<?= site_url() ?>/simulacao" class="cta d-block d-lg-none mt-3">Simule aqui</a>
        </div>
    </header>