<?php

/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage None Plate
 * @since None Plate 1.0
 */

get_header(); ?>

<main>
    <section class="hero-section">
        <?php
        $hero = get_field('hero');
        $desktop = $hero['desktop'];
        $mobile = $hero['mobile'];
        $fallback = IMG_URI . 'hero.jpg';
        $img_src = $desktop ? $desktop : $fallback;
        ?>
        <picture>
            <?php if ($mobile): ?>
                <source media="(max-width: 767px)" srcset="<?= esc_url($mobile); ?>" type="image/jpeg">
            <?php endif; ?>
            <?php if ($desktop): ?>
                <source media="(min-width: 768px)" srcset="<?= esc_url($desktop); ?>" type="image/jpeg">
            <?php endif; ?>
            <img src="<?= esc_url($img_src); ?>" alt="Display da Home" class="hero-img" loading="lazy" decoding="async">
        </picture>
        <div class="hero-content">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="texto d-flex flex-column align-items-center text-center text-lg-start">
                            <p><a href="<?= home_url() ?>">Início</a>&nbsp;>&nbsp;Sobre a Roquexc</p>
                            <h1><?= get_field('titulo_banner') ?? 'Conheça a <span>Roquexc Construtora</span>'  ?></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="sobre my-5 py-4">
        <div class="container">
            <div class="row gap-4 gap-lg-0">
                <?php
                $sobre = get_field('sobre');
                $img = $sobre['imagem'];
                $titulo = $sobre['titulo'];
                $texto = $sobre['texto'];
                ?>
                <div class="col-lg-6">
                    <img class="img-sobre" src="<?= $img ?>" alt="">
                </div>
                <div class="col-lg-6">
                    <span>NOSSA HISTÓRIA</span>
                    <h2><?= $titulo; ?></h2>
                    <p><?= nl2br($texto); ?></p>
                </div>
            </div>
        </div>
    </section>
    <section class="mvv">
        <div class="container">
            <div class="row">
                <div class="text-center">
                    <h2 class="titulo-numeros">Missão, Visão e Valores</h2>
                </div>
                <div class="d-flex flex-wrap flex-lg-nowrap align-items-center gap-4 mt-4">
                    <div class="numero-box">
                        <img src="<?= IMG_URI ?>trophy.svg" alt="">
                        <h3>Missão</h3>
                        <p>Construir com qualidade e compromisso,
                            concretizando projetos que transformam e inspiram, pensando em cada detalhe, onde as pessoas prosperam e se realizam.</p>
                    </div>
                    <div class="numero-box">
                        <img src="<?= IMG_URI ?>trophy.svg" alt="">
                        <h3>Visão</h3>
                        <p>Construir com qualidade e compromisso,
                            concretizando projetos que transformam e inspiram, pensando em cada detalhe, onde as pessoas prosperam e se realizam.</p>
                    </div>
                    <div class="numero-box">
                        <img src="<?= IMG_URI ?>trophy.svg" alt="">
                        <h3>Valores</h3>
                        <p>Construir com qualidade e compromisso,
                            concretizando projetos que transformam e inspiram, pensando em cada detalhe, onde as pessoas prosperam e se realizam.</p>
                    </div>
                </div>
            </div>
        </div>
        <img class="bg-logo" src="<?= IMG_URI ?>rocx.svg" alt="">
    </section>
    <section class="parceiros">
        <div class="container">
            <div class="row">
                <div class="d-block">
                    <div class="text-center my-5">
                        <h2>Nossos Parceiros</h2>
                    </div>
                    <div class="swiper-container">
                        <div class="swiper parceiros">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="card">
                                        <img src="<?= IMG_URI ?>LogosMTbroker.png" alt="">
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card">
                                        <img src="<?= IMG_URI ?>LogosMTbroker.png" alt="">
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card">
                                        <img src="<?= IMG_URI ?>LogosMTbroker.png" alt="">
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card">
                                        <img src="<?= IMG_URI ?>LogosMTbroker.png" alt="">
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card">
                                        <img src="<?= IMG_URI ?>LogosMTbroker.png" alt="">
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card">
                                        <img src="<?= IMG_URI ?>LogosMTbroker.png" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-controls">
                            <div class="swiper-button-prev"></div>
                            <div class="swiper-button-next"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="sobre mt-5 pt-4">
        <div class="container">
            <div class="row">
                <?php
                $qualidade = get_field('politica_de_qualidade');
                $img = $qualidade['imagem'];
                $titulo = $qualidade['titulo'];
                $texto = $qualidade['texto'];
                ?>
                <div class="col-lg-6">
                    <span>POLÍTICA DE QUALIDADE</span>
                    <h2><?= $titulo; ?></h2>
                    <p><?= nl2br($texto); ?></p>
                </div>
                <div class="col-lg-6">
                    <img class="img-sobre" src="<?= $img ?>" alt="">
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const swiper = new Swiper('.swiper.parceiros', {
            slidesPerView: 3,
            spaceBetween: 32,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev'
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                    spaceBetween: 20
                },
                768: {
                    slidesPerView: 2,
                    spaceBetween: 30
                },
                992: {
                    slidesPerView: 3,
                    spaceBetween: 32,
                }
            }
        });
    })
</script>