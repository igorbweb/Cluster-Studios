<?php

/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage None Plate
 * @since None Plate 1.0
 */

get_header(); ?>

<main>
    <section class="hero-section home">
        <img
            src="<?= get_template_directory_uri(); ?>/assets/img/singularity.gif"
            alt="Display da Home"
            class="hero-img"
            decoding="async">

        <div class="hero-content">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="texto d-flex flex-column text-center align-items-center gap-4">
                            <h1><?= get_field('titulo_banner') ?? 'Where Worlds<br>Come to <span>Life.</span>'  ?></h1>
                            <p>We create immersive, story-driven and visually striking game experiences.<br>
                                From concept to launch, our team blends creativity and technology to build worlds players want to return to.</p>
                            <a class="cta" href="">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/office.jpg" alt="">
                </div>
                <div class="col-lg-5">
                    <div class="texto d-flex flex-column justify-content-between h-100">
                        <h2>Built by Players, for Players</h2>
                        <p>Our mission is simple: craft games with heart, vision, and unforgettable gameplay.
                            We’re a small, dedicated team of designers, developers, and storytellers passionate about pushing boundaries while keeping a tight focus on quality.
                            <br><br>Every pixel, every mechanic, every moment—designed with intention.
                            <br>We create immersive, story-driven and visually striking game experiences.
                            From concept to launch, our team blends creativity and technology to build worlds players want to return to.
                            <br><br>
                            Play. Discover. Explore.
                        </p>
                        <a href="/about-us" class="cta">About Us</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="games">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="texto d-flex flex-column gap-3 h-100">
                        <h2>Crafted Experiences</h2>
                        <p>Explore our catalog of original games, each built with its own identity and playstyle.
                            Whether it's fast-paced action, atmospheric adventures, or strategy that challenges your mind, our goal remains the same: deliver experiences that feel alive.</p>
                        <a class="cta" href="">
                            Dive into our worlds
                        </a>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="swiper games">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="card-game">
                                    <div class="thumb">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/rdr2.webp" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card-game">
                                    <div class="thumb">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/rdr2.webp" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card-game">
                                    <div class="thumb">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/rdr2.webp" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="services">
        <div class="container">
            <div class="row g-4">
                <div class="col-12 col-md-12">
                    <div class="card-service">
                        <div class="thumb">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Game-Development.webp" alt="">
                        </div>
                        <div class="text">
                            <h3>Game Development</h3>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="card-service">
                        <div class="thumb">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/feature.webp" alt="">
                        </div>
                        <div class="text">
                            <h3>Feature/System Development</h3>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="card-service">
                        <div class="thumb">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/Game-Development.webp" alt="">
                        </div>
                        <div class="text">
                            <h3>Consultancy</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <canvas id="starfield"></canvas>

    <section class="contact">
        <div class="container">
            <div class="section-container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="text">
                            <h2>Let’s Build Something Incredible</h2>
                            <p>Have a project, collaboration, or idea in mind?<br>
                                Reach out and let’s shape your next game together.<br><br>
                                <bold>We’d love to hear from you.</bold>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-container">
                            <div class="head text-center my-4">
                                <h3>Send us a Message</h3>
                            </div>
                            <form class="d-flex h-100 flex-column justify-content-between" action="" method="post">
                                <div class="input">
                                    <input class="form-control mb-3" type="text" name="name" id="name" placeholder="Name">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.1012 10.2312C14.0425 9.49475 14.7295 8.48481 15.0667 7.34193C15.4039 6.19904 15.3746 4.98004 14.9827 3.85452C14.5909 2.729 13.8561 1.75292 12.8805 1.06208C11.9048 0.371243 10.737 0 9.53933 0C8.34169 0 7.17382 0.371243 6.1982 1.06208C5.22259 1.75292 4.48775 2.729 4.09591 3.85452C3.70408 4.98004 3.67473 6.19904 4.01195 7.34193C4.34918 8.48481 5.03621 9.49475 5.97746 10.2312C4.3646 10.8739 2.95734 11.9397 1.90568 13.3152C0.854015 14.6906 0.197386 16.3241 0.00579102 18.0415C-0.00807765 18.1669 0.00302268 18.2938 0.038458 18.4149C0.0738933 18.536 0.13297 18.649 0.212314 18.7475C0.372558 18.9462 0.60563 19.0735 0.860258 19.1014C1.11489 19.1292 1.37021 19.0554 1.57006 18.896C1.76992 18.7366 1.89793 18.5048 1.92594 18.2516C2.13676 16.3851 3.03165 14.6613 4.43963 13.4096C5.84761 12.1578 7.66997 11.4658 9.55853 11.4658C11.4471 11.4658 13.2695 12.1578 14.6774 13.4096C16.0854 14.6613 16.9803 16.3851 17.1911 18.2516C17.2172 18.4862 17.3298 18.7029 17.5071 18.8598C17.6844 19.0168 17.9139 19.1028 18.1512 19.1014H18.2568C18.5085 19.0726 18.7385 18.946 18.8968 18.7493C19.055 18.5526 19.1287 18.3016 19.1017 18.0511C18.9092 16.3288 18.249 14.6911 17.1919 13.3135C16.1349 11.936 14.7208 10.8705 13.1012 10.2312ZM9.53933 9.55331C8.77979 9.55331 8.03731 9.32932 7.40578 8.90966C6.77424 8.49 6.28202 7.89351 5.99136 7.19564C5.7007 6.49777 5.62464 5.72985 5.77282 4.98899C5.921 4.24814 6.28676 3.56761 6.82383 3.03349C7.36091 2.49936 8.04518 2.13561 8.79013 1.98825C9.53507 1.84088 10.3072 1.91651 11.009 2.20558C11.7107 2.49465 12.3104 2.98417 12.7324 3.61224C13.1544 4.24031 13.3796 4.97872 13.3796 5.73409C13.3796 6.74701 12.975 7.71844 12.2548 8.43469C11.5346 9.15093 10.5578 9.55331 9.53933 9.55331Z" fill="#C8AC78" />
                                    </svg>
                                </div>

                                <div class="input">
                                    <input class="form-control mb-3" type="mail" name="email" id="email" placeholder="E-mail">
                                    <svg width="20" height="15" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0.599609 0.599609H18.4329V13.2316C18.4329 13.4286 18.3547 13.6176 18.2153 13.757C18.076 13.8963 17.887 13.9746 17.6899 13.9746H1.34266C1.14559 13.9746 0.956595 13.8963 0.817245 13.757C0.677896 13.6176 0.599609 13.4286 0.599609 13.2316V0.599609Z" stroke="#C8AC78" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M18.4329 0.599609L9.51628 8.40169L0.599609 0.599609" stroke="#C8AC78" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </div>

                                <div class="input">
                                    <input class="form-control mb-3" type="phone" name="phone" id="phone" placeholder="Phone">
                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.623 9.83673C15.4261 9.83673 15.2203 9.77391 15.0234 9.72903C14.6247 9.64092 14.2329 9.52394 13.8511 9.37901C13.4359 9.22754 12.9796 9.23541 12.5699 9.4011C12.1602 9.56678 11.8261 9.87858 11.6318 10.2765L11.4349 10.6804C10.5633 10.1941 9.76237 9.59013 9.05454 8.8854C8.35185 8.1755 7.74965 7.37223 7.26478 6.49808L7.64063 6.24679C8.03739 6.05196 8.34828 5.71685 8.51349 5.30594C8.6787 4.89504 8.68654 4.43738 8.53551 4.02102C8.39342 3.63728 8.27683 3.24451 8.18651 2.84532C8.14176 2.64787 8.10597 2.44145 8.07912 2.23502C7.97045 1.60285 7.64029 1.03037 7.14811 0.620662C6.65592 0.210958 6.03405 -0.00904113 5.39448 0.000284775H2.70984C2.32418 -0.00334694 1.94226 0.0764036 1.59009 0.234107C1.23792 0.391811 0.923764 0.623765 0.66901 0.914178C0.414256 1.20459 0.224885 1.54665 0.113789 1.91706C0.00269242 2.28747 -0.0275206 2.67754 0.0252062 3.06071C0.501943 6.82062 2.21411 10.3141 4.89125 12.9893C7.56839 15.6645 11.0579 17.3689 14.8086 17.8333H15.1487C15.8086 17.8343 16.4457 17.5915 16.9384 17.1512C17.2215 16.8973 17.4477 16.586 17.6019 16.2379C17.7562 15.8898 17.8351 15.5128 17.8333 15.1319V12.4394C17.8223 11.816 17.596 11.2158 17.1929 10.7411C16.7898 10.2664 16.2349 9.94679 15.623 9.83673ZM16.0704 15.2216C16.0702 15.3491 16.043 15.475 15.9906 15.5911C15.9381 15.7071 15.8616 15.8107 15.7661 15.8948C15.6661 15.9813 15.5492 16.046 15.4229 16.0847C15.2965 16.1233 15.1635 16.135 15.0323 16.1191C11.6809 15.6882 8.56794 14.1505 6.18441 11.7486C3.80088 9.34679 2.28246 6.21747 1.86866 2.85429C1.85442 2.72282 1.8669 2.58983 1.90535 2.46334C1.9438 2.33685 2.00743 2.21949 2.09238 2.11835C2.17624 2.02262 2.27946 1.94589 2.39519 1.89328C2.51091 1.84066 2.63648 1.81337 2.76354 1.81321H5.44817C5.65628 1.80856 5.85948 1.87682 6.02282 2.00623C6.18615 2.13564 6.29939 2.3181 6.34305 2.52222C6.37885 2.76753 6.42359 3.00985 6.47729 3.24918C6.58066 3.72229 6.71824 4.18722 6.88893 4.64029L5.6361 5.22365C5.52898 5.27294 5.43262 5.34297 5.35256 5.42971C5.2725 5.51645 5.21032 5.6182 5.16957 5.72911C5.12883 5.84002 5.11033 5.95791 5.11514 6.07601C5.11995 6.19412 5.14798 6.3101 5.19761 6.41731C6.48552 9.18404 8.70307 11.408 11.4618 12.6997C11.6796 12.7895 11.924 12.7895 12.1419 12.6997C12.2535 12.6597 12.356 12.5978 12.4436 12.5177C12.5312 12.4376 12.602 12.3408 12.652 12.233L13.2068 10.9765C13.6694 11.1425 14.1416 11.2803 14.6207 11.3894C14.8593 11.4432 15.1009 11.4881 15.3455 11.524C15.5491 11.5678 15.731 11.6814 15.86 11.8452C15.9891 12.009 16.0571 12.2128 16.0525 12.4215L16.0704 15.2216Z" fill="#C8AC78" />
                                    </svg>
                                </div>
                                <textarea class="form-control mb-3" rows="5" cols="33" name="mensagem" id="mensagem">Digite aqui sua mensagem:</textarea>
                                <div class="d-flex justify-content-center">
                                    <button type="submit" href="" class="cta mt-2">Enviar Cadastro</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<style>
    #starfield {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: block;
        z-index: -1;
        filter: brightness(0.5);
        pointer-events: none;
    }

    section.about {
        background-color: transparent;
    }

    section.games {
        overflow: hidden;

        .texto {
            position: relative;
            z-index: 10;

            &::after {
                content: '';
                z-index: -1;
                display: block;
                position: absolute;
                height: 100%;
                width: 205%;
                left: -100%;
                background-color: #0a0a0a;
            }
        }

        .swiper.games {
            overflow: visible;
        }
    }

    section.contact {
        background-color: transparent;

        .section-container {
            padding: 64px;
            border: 1px solid rgb(82, 82, 82);
            border-radius: 5px;
            background-color: rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(3px);
        }
    }
</style>

<?php get_footer(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var swiperGames = new Swiper('.swiper.games', {
            slidesPerView: 1.8,
            spaceBetween: 32,
            loop: false,
        })
    })
    const canvas = document.getElementById("starfield");
    const ctx = canvas.getContext("2d");

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    let stars = [];
    const STAR_COUNT = 500;

    const BASE_SPEED_MULTIPLIER = 1;

    let scrollVelocity = 0;
    let lastScrollY = window.scrollY;

    function random(min, max) {
        return Math.random() * (max - min) + min;
    }

    function init() {
        stars = [];

        for (let i = 0; i < STAR_COUNT; i++) {
            let size_pre = Math.random() * 0.9 + 0.1;

            let star = {
                x: random(0, width + 20),
                y: random(0, height),
                size: size_pre * 2.0,
                baseSpeed: size_pre * 2.0 * (0.08 + Math.random() * 0.2),
                r: 0.85 + Math.random() * (1.0 - 0.85),
                g: 0.85 + Math.random() * (1.0 - 0.85) * 0.5,
                b: 0.85 + Math.random() * (1.0 - 0.85),
                a: Math.random()
            };

            if (i < 1500) {
                star.size += 1.0;
                star.a += 0.3;
            }

            stars.push(star);
        }
    }

    window.addEventListener("scroll", () => {
        let newY = window.scrollY;

        // velocidade absoluta (NUNCA inverte direção)
        scrollVelocity = Math.abs(newY - lastScrollY) * 0.3;

        lastScrollY = newY;
    });

    function easeScrollVelocity() {
        scrollVelocity *= 0.9;
    }

    function draw() {
        ctx.clearRect(0, 0, width, height);
        easeScrollVelocity();

        for (let s of stars) {
            s.x -= s.baseSpeed * BASE_SPEED_MULTIPLIER + scrollVelocity;

            if (s.x < -2) {
                s.x = width + 20;
                s.y = random(0, height);
            }

            ctx.fillStyle = `rgba(${s.r * 255}, ${s.g * 255}, ${s.b * 255}, ${s.a})`;
            ctx.beginPath();
            ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
            ctx.fill();
        }

        requestAnimationFrame(draw);
    }

    window.addEventListener("resize", () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
        init();
    });

    init();
    draw();
</script>