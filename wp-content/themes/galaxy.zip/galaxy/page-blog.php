<?php

/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage None Plate
 * @since None Plate 1.0
 */

get_header(); ?>

<main>
    <section class="hero-section">
        <?php
        $hero = get_field('hero') ?: [];
        $desktop = $hero['desktop'] ?? '';
        $mobile = $hero['mobile'] ?? '';
        $fallback = IMG_URI . 'hero.jpg';
        $img_src = $desktop ?: $fallback;
        ?>
        <picture>
            <?php if ($mobile): ?>
                <source media="(max-width: 767px)" srcset="<?= esc_url($mobile); ?>" type="image/jpeg">
            <?php endif; ?>
            <?php if ($desktop): ?>
                <source media="(min-width: 768px)" srcset="<?= esc_url($desktop); ?>" type="image/jpeg">
            <?php endif; ?>
            <img src="<?= esc_url($img_src); ?>" alt="Display da Home" class="hero-img" loading="lazy" decoding="async">
        </picture>
        <div class="hero-content">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="texto d-flex flex-column align-items-center text-center text-lg-start">
                            <p><a href="<?= home_url() ?>">Início</a>&nbsp;>&nbsp;<?= get_the_title(); ?></p>
                            <h1><?= get_field('titulo_banner') ?? 'Fique por dentro das <span>novidades</span>'  ?></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="blog-destaque my-5">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-5">
                    <h2>Todos os Empreendimentos da Roquexc</h2>
                </div>
            </div>
            <div class="row gap-4 gap-lg-0">
                <div class="col-lg-6">
                    <img class="img-sobre" src="<?= IMG_URI ?>foto (7).jpg" alt="">
                </div>
                <div class="col-lg-6">
                    <div class="d-flex flex-column justify-content-between h-100 gap-3 gap-lg-0">
                        <span>NOTÍCIA DE DESTAQUE</span>
                        <h2>Construção Sustentável: como a tecnologia está mudando a forma de construir no Brasil</h2>
                        <p>Nos últimos anos, o setor da construção civil tem passado por uma verdadeira transformação, impulsionada pelo avanço da tecnologia e pela crescente preocupação com o meio ambiente. Termos como construção sustentável, eficiência energética e materiais ecológicos já fazem parte do dia a dia de engenheiros, arquitetos e incorporadoras que buscam um futuro mais verde — e mais econômico.</p>
                        <a href="#" class="cta">Leia a notícia completa</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="blog-listagem">
        <div class="container">
            <div class="row gap-4 gap-lg-0">
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        <div class="card-thumb">
                            <img src="<?= IMG_URI ?>avenue-with-green-trees.jpg" alt="">
                            <span>Sustentabilidade</span>
                        </div>
                        <div class="card-body d-flex flex-column gap-3 p-4">
                            <div class="info d-flex justify-content-between">
                                <div class="date">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19 4H18V2H16V4H8V2H6V4H5C3.9 4 3 4.9 3 6V20C3 21.1 3.9 22 5 22H19C20.1 22 21 21.1 21 20V6C21 4.9 20.1 4 19 4ZM19 20H5V10H19V20ZM5 8V6H19V8H5ZM7 12H17V14H7V12ZM7 16H14V18H7V16Z" fill="#472135" />
                                    </svg>
                                    &nbsp; <?php echo get_the_date(); ?>
                                </div>
                                <div class="date">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_7013_1918)">
                                            <path d="M17.849 11.808L17.142 11.101L7.242 21.001H3V16.758L14.313 5.44403L19.97 11.101C20.1575 11.2886 20.2628 11.5429 20.2628 11.808C20.2628 12.0732 20.1575 12.3275 19.97 12.515L12.9 19.586L11.485 18.172L17.849 11.808ZM15.728 9.68703L14.313 8.27303L5 17.586V19.001H6.414L15.728 9.68703ZM18.556 2.61603L21.385 5.44403C21.5725 5.63156 21.6778 5.88586 21.6778 6.15103C21.6778 6.41619 21.5725 6.6705 21.385 6.85803L19.97 8.27303L15.728 4.03003L17.142 2.61603C17.3295 2.42856 17.5838 2.32324 17.849 2.32324C18.1142 2.32324 18.3685 2.42856 18.556 2.61603Z" fill="#472135" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_7013_1918">
                                                <rect width="24" height="24" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                    &nbsp; Equipe Roquexc
                                </div>
                            </div>
                            <div class="texto">
                                <h3>Tendências em Arquitetura Sustentável para 2025.</h3>
                                <p>Descubra as principais tendências que estão moldando o futuro da construção civil com foco na sustentabilidade...</p>
                            </div>
                            <a href="/single" class="cta">Ler Mais</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        <div class="card-thumb">
                            <img src="<?= IMG_URI ?>avenue-with-green-trees.jpg" alt="">
                            <span>Sustentabilidade</span>
                        </div>
                        <div class="card-body d-flex flex-column gap-3 p-4">
                            <div class="info d-flex justify-content-between">
                                <div class="date">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19 4H18V2H16V4H8V2H6V4H5C3.9 4 3 4.9 3 6V20C3 21.1 3.9 22 5 22H19C20.1 22 21 21.1 21 20V6C21 4.9 20.1 4 19 4ZM19 20H5V10H19V20ZM5 8V6H19V8H5ZM7 12H17V14H7V12ZM7 16H14V18H7V16Z" fill="#472135" />
                                    </svg>
                                    &nbsp; <?php echo get_the_date(); ?>
                                </div>
                                <div class="date">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_7013_1918)">
                                            <path d="M17.849 11.808L17.142 11.101L7.242 21.001H3V16.758L14.313 5.44403L19.97 11.101C20.1575 11.2886 20.2628 11.5429 20.2628 11.808C20.2628 12.0732 20.1575 12.3275 19.97 12.515L12.9 19.586L11.485 18.172L17.849 11.808ZM15.728 9.68703L14.313 8.27303L5 17.586V19.001H6.414L15.728 9.68703ZM18.556 2.61603L21.385 5.44403C21.5725 5.63156 21.6778 5.88586 21.6778 6.15103C21.6778 6.41619 21.5725 6.6705 21.385 6.85803L19.97 8.27303L15.728 4.03003L17.142 2.61603C17.3295 2.42856 17.5838 2.32324 17.849 2.32324C18.1142 2.32324 18.3685 2.42856 18.556 2.61603Z" fill="#472135" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_7013_1918">
                                                <rect width="24" height="24" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                    &nbsp; Equipe Roquexc
                                </div>
                            </div>
                            <div class="texto">
                                <h3>Tendências em Arquitetura Sustentável para 2025.</h3>
                                <p>Descubra as principais tendências que estão moldando o futuro da construção civil com foco na sustentabilidade...</p>
                            </div>
                            <a href="#" class="cta">Ler Mais</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        <div class="card-thumb">
                            <img src="<?= IMG_URI ?>avenue-with-green-trees.jpg" alt="">
                            <span>Sustentabilidade</span>
                        </div>
                        <div class="card-body d-flex flex-column gap-3 p-4">
                            <div class="info d-flex justify-content-between">
                                <div class="date">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19 4H18V2H16V4H8V2H6V4H5C3.9 4 3 4.9 3 6V20C3 21.1 3.9 22 5 22H19C20.1 22 21 21.1 21 20V6C21 4.9 20.1 4 19 4ZM19 20H5V10H19V20ZM5 8V6H19V8H5ZM7 12H17V14H7V12ZM7 16H14V18H7V16Z" fill="#472135" />
                                    </svg>
                                    &nbsp; <?php echo get_the_date(); ?>
                                </div>
                                <div class="date">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_7013_1918)">
                                            <path d="M17.849 11.808L17.142 11.101L7.242 21.001H3V16.758L14.313 5.44403L19.97 11.101C20.1575 11.2886 20.2628 11.5429 20.2628 11.808C20.2628 12.0732 20.1575 12.3275 19.97 12.515L12.9 19.586L11.485 18.172L17.849 11.808ZM15.728 9.68703L14.313 8.27303L5 17.586V19.001H6.414L15.728 9.68703ZM18.556 2.61603L21.385 5.44403C21.5725 5.63156 21.6778 5.88586 21.6778 6.15103C21.6778 6.41619 21.5725 6.6705 21.385 6.85803L19.97 8.27303L15.728 4.03003L17.142 2.61603C17.3295 2.42856 17.5838 2.32324 17.849 2.32324C18.1142 2.32324 18.3685 2.42856 18.556 2.61603Z" fill="#472135" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_7013_1918">
                                                <rect width="24" height="24" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                    &nbsp; Equipe Roquexc
                                </div>
                            </div>
                            <div class="texto">
                                <h3>Tendências em Arquitetura Sustentável para 2025.</h3>
                                <p>Descubra as principais tendências que estão moldando o futuro da construção civil com foco na sustentabilidade...</p>
                            </div>
                            <a href="#" class="cta">Ler Mais</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>